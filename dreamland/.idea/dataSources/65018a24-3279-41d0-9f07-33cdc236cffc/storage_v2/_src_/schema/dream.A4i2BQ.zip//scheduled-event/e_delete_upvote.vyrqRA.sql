create definer = root@localhost event e_delete_upvote on schedule
    every '1' DAY
        starts '2019-07-20 00:00:00'
    on completion preserve
    enable
    do
    TRUNCATE TABLE dream_db.upvote;

